var child = [
  { 'dupe': false, 'type': 2, 'name': 'http://127.0.0.1:8000/', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1:8000/', 'fetched': true, 'code': 200, 'len': 528, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'missing': false, 'csens': false, 'child_cnt': 36, 'issue_cnt': [ 26, 42, 1, 3, 0 ], 'sig': 0x17723e05 }
];
