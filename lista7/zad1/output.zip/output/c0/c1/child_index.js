var child = [
  { 'dupe': false, 'type': 4, 'name': 'jakub', 'dir': 'c0', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/', 'fetched': true, 'code': 404, 'len': 2856, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': true, 'csens': false, 'child_cnt': 18, 'issue_cnt': [ 2, 18, 0, 0, 0 ], 'sig': 0x192aff11 }
];
