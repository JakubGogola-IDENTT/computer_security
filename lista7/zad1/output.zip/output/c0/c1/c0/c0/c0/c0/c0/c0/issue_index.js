var issue = [
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'inject behavior', 'fetched': false, 'error': 'Connection error', 'dir': 'i0' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Frame-Options', 'fetched': true, 'code': 404, 'len': 2982, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10202, 'sid': '0', 'extra': 'WSGIServer/0.2 CPython/3.6.7', 'fetched': true, 'code': 404, 'len': 2982, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' }
];
