var child = [
  { 'dupe': false, 'type': 32, 'name': 'base_user.py', 'dir': 'c0', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/.local/lib/python3.6/site-packages/django/contrib/auth/base_user.py', 'fetched': true, 'code': 404, 'len': 3057, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffdfffff },
  { 'dupe': false, 'type': 32, 'name': 'forms.py', 'dir': 'c1', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/.local/lib/python3.6/site-packages/django/contrib/auth/forms.py', 'fetched': false, 'error': 'Connection error', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 1, 0, 0, 0 ], 'sig': 0x6a841831 }
];
