var child = [
  { 'dupe': false, 'type': 4, 'name': 'django', 'dir': 'c0', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/.local/lib/python3.6/site-packages/django/', 'fetched': true, 'code': 404, 'len': 2982, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 13, 'issue_cnt': [ 2, 13, 0, 0, 0 ], 'sig': 0xb9bff52f }
];
