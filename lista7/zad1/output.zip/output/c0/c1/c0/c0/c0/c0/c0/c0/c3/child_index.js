var child = [
  { 'dupe': false, 'type': 4, 'name': 'generic', 'dir': 'c0', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/.local/lib/python3.6/site-packages/django/views/generic/', 'fetched': true, 'code': 404, 'len': 3024, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 1, 0, 0, 0 ], 'sig': 0xd54de38c }
];
