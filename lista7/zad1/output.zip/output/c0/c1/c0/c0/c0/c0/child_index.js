var child = [
  { 'dupe': false, 'type': 4, 'name': 'site-packages', 'dir': 'c0', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/.local/lib/python3.6/site-packages/', 'fetched': false, 'error': 'Connection error', 'missing': false, 'csens': false, 'child_cnt': 14, 'issue_cnt': [ 2, 14, 0, 0, 0 ], 'sig': 0x39d93d05 }
];
