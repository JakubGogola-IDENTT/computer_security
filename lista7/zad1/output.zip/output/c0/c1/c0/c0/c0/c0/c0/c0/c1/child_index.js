var child = [
  { 'dupe': false, 'type': 4, 'name': 'handlers', 'dir': 'c0', 'linked': 1, 'url': 'http://127.0.0.1:8000/home/jakub/.local/lib/python3.6/site-packages/django/core/handlers/', 'fetched': false, 'error': 'Connection error', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 1, 0, 0, 0 ], 'sig': 0xc7ca4284 }
];
