var issue = [
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'param behavior', 'fetched': false, 'error': 'Connection error', 'dir': 'i0' },
  { 'severity': 0, 'type': 10401, 'sid': '0', 'extra': '', 'fetched': true, 'code': 403, 'len': 2513, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' }
];
