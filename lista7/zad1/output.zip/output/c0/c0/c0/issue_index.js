var issue = [
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'during 404 response checks', 'fetched': false, 'error': 'Connection error', 'dir': 'i0' },
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'inject behavior', 'fetched': false, 'error': 'Connection error', 'dir': 'i1' },
  { 'severity': 0, 'type': 10602, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 917, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i2' },
  { 'severity': 0, 'type': 10205, 'sid': '0', 'extra': '', 'fetched': true, 'code': 404, 'len': 4424, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' },
  { 'severity': 0, 'type': 10201, 'sid': '0', 'extra': 'csrftoken', 'fetched': true, 'code': 200, 'len': 18, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i4' }
];
