var issue = [
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'during 404 response checks', 'fetched': false, 'error': 'Connection error', 'dir': 'i0' },
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'during parent checks', 'fetched': false, 'error': 'Connection error', 'dir': 'i1' },
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'SQL injection', 'fetched': false, 'error': 'Connection error', 'dir': 'i2' }
];
