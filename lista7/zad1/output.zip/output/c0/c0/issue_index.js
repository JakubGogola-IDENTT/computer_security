var issue = [
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'Shell injection (diff)', 'fetched': false, 'error': 'Connection error', 'dir': 'i0' }
];
