var issue = [
  { 'severity': 3, 'type': 40201, 'sid': '0', 'extra': 'http://dpaste.com/', 'fetched': true, 'code': 500, 'len': 178924, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i0' },
  { 'severity': 1, 'type': 20101, 'sid': '0', 'extra': 'param behavior', 'fetched': false, 'error': 'Connection error', 'dir': 'i1' },
  { 'severity': 0, 'type': 10403, 'sid': '0', 'extra': '', 'fetched': true, 'code': 500, 'len': 178924, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10401, 'sid': '0', 'extra': '', 'fetched': true, 'code': 500, 'len': 178924, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' }
];
