var child = [
  { 'dupe': false, 'type': 4, 'name': 'style.css', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1:8000/static/style.css/', 'fetched': true, 'code': 200, 'len': 449, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 1, 0, 0, 0 ], 'sig': 0xb5aaeece }
];
