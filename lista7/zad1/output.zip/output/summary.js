var sf_version = '2.10b';
var scan_date  = 'Sun Dec  9 18:33:41 2018';
var scan_seed  = '0x47113de9';
var scan_ms    = 2776703;
