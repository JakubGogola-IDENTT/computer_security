#!/bin/bash

skipfish -o output -A gogolix:kwakwarakwa -S complete.wl -W output_dict.wl http://127.0.0.1:8000/
